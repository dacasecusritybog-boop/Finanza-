-- Ejecuta este SQL en Supabase > SQL Editor.
create table if not exists public.user_finances (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"tx":[],"accts":["Efectivo","Bancolombia","Nequi","Daviplata","Tarjeta de crédito"],"budgets":{}}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_finances enable row level security;
create policy "Cada usuario lee sus finanzas" on public.user_finances for select to authenticated using (auth.uid() = user_id);
create policy "Cada usuario crea sus finanzas" on public.user_finances for insert to authenticated with check (auth.uid() = user_id);
create policy "Cada usuario actualiza sus finanzas" on public.user_finances for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
