# VERSIÓN 1.3 (la app muestra su versión al final de la pestaña Ajustes)

# Mis Finanzas — proyectos nativos (Android Studio + Xcode)

App de finanzas personales (COP). El mismo código web corre dentro de un
proyecto nativo de Android y otro de iPhone usando Capacitor.

Estructura
- `www/`      → la app (index.html). Es lo único que editas para cambiar la app.
- `android/`  → proyecto de Android Studio
- `ios/`      → proyecto de Xcode (iPhone)

## Android (Android Studio)
0. (Ya incluye la carpeta node_modules; si la borras, ejecuta `npm install` antes.)
1. Abre Android Studio → **Open** → selecciona la carpeta `android/`.
2. Espera a que termine "Gradle Sync".
3. Conecta el celular (Depuración USB activada) o crea un emulador y pulsa ▶ Run.
4. APK/AAB para publicar: Build → Generate Signed Bundle / APK.

## iPhone (Xcode — requiere Mac)
1. En una Mac instala Node.js y CocoaPods (`sudo gem install cocoapods` o `brew install cocoapods`).
2. En esta carpeta: `npm install` y luego `npx cap sync ios`.
3. Abre `ios/App/App.xcworkspace` en Xcode.
4. En Signing & Capabilities elige tu Team (Apple ID).
5. Elige tu iPhone o un simulador y pulsa ▶ Run.
   (Para App Store: Product → Archive.)

## Si cambias la app
Edita `www/index.html` y ejecuta `npx cap sync` (copia los cambios a ambos proyectos).

ID de la app: `com.dacatech.misfinanzas` (cámbialo en capacitor.config.json
y en android/app/build.gradle / Xcode si quieres otro).

## Registro automático de movimientos (solo Android)
La app incluye un servicio nativo (`BankNotificationListener.java`) que lee las
notificaciones y SMS del teléfono que parecen movimientos de dinero (compra, pago,
transferencia, abono) y los registra solos con el ícono 🤖.

Activarlo (una sola vez en el celular):
1. Abre la app → pestaña **Ajustes** → **Activar acceso a notificaciones**.
2. En la pantalla de Android activa el interruptor de **Mis Finanzas**.
   (En Android 13+, si el interruptor sale gris: Ajustes del sistema → Apps → Mis Finanzas →
   menú ⋮ → *Permitir ajustes restringidos*, y vuelve a intentar.)
3. Recomendado: desactiva la optimización de batería para Mis Finanzas.

Notas
- Todo se procesa dentro del teléfono; no se envía nada a ningún servidor.
- Ignora WhatsApp, Telegram, Gmail y redes sociales; descarta mensajes de claves/códigos y promociones.
- Si el mismo movimiento llega por la app y por SMS, solo se registra una vez.
- La detección se basa en el texto del mensaje; si un banco usa otro formato y algo no se
  registra o queda mal categorizado, se corrige tocando el movimiento. Las reglas están en
  `parseBank()` dentro de `www/index.html`.
- En iPhone iOS no permite leer notificaciones de otras apps, por eso allá se usa
  el botón **Pegar mensaje del banco**.

## Cuentas, confirmación por correo, recuperación y nube
Esta versión incluye interfaz de registro/inicio de sesión con Supabase Auth, confirmación de correo, recuperación de contraseña y sincronización de movimientos por usuario. Antes de compilar/publicar:
1. Crea un proyecto en Supabase.
2. Ejecuta `supabase-schema.sql` en SQL Editor.
3. Copia la URL del proyecto y la clave pública `anon` en `www/cloud-config.js` (no uses una `service_role` key).
4. En Supabase > Authentication > URL Configuration, configura la URL de tu app/sitio como Site URL y agrega las URLs de redirección permitidas. Configura SMTP/correo en Supabase para entregar los mensajes de confirmación y recuperación de forma fiable.
5. Copia los cambios a Android ejecutando `npx cap sync` desde la carpeta del proyecto; si ya abres el proyecto Android directamente, comprueba que `android/app/src/main/assets/public/` tenga los mismos archivos de `www/`.

Los movimientos quedan separados por usuario y la tabla aplica Row Level Security. Si no configuras Supabase, la pantalla de acceso muestra un aviso y no deja entrar a los datos; esto evita que usuarios distintos compartan movimientos en el mismo teléfono.

## Notificaciones de bancos y cuentas de ahorro
En Android, el lector no está limitado a Nequi: examina las notificaciones de las aplicaciones instaladas y guarda las que parezcan movimientos financieros (pagos, compras, transferencias, abonos, consignaciones o retiros) y tengan un monto reconocible. Puede funcionar con bancos y billeteras como Bancolombia, Davivienda, BBVA, Nu, Nequi, Daviplata y otras, siempre que Android muestre el aviso y su texto incluya información que el detector reconozca. No se conecta a las cuentas ni lee saldos dentro de las apps; solo procesa notificaciones visibles y autorizadas.

Para activarlo, habilita **Acceso a notificaciones** para Mis Finanzas en los ajustes de Android. La detección no puede garantizar todos los formatos: depende de cada entidad y del texto que llegue al teléfono. En iPhone, iOS no permite a una app leer las notificaciones de otras aplicaciones; allí se debe pegar el mensaje manualmente.
